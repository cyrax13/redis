
#ifndef __FAST_FLOAT_STRTOD_H__
#define __FAST_FLOAT_STRTOD_H__

#if defined(__cplusplus)
extern "C"
{
#endif
    double fast_float_strtod(const char *in, char **out);

#if defined(__cplusplus)
}
#endif

#endif /* __FAST_FLOAT_STRTOD_H__ */
